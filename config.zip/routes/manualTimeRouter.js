const express = require('express');
const manualTimeController = require('../controllers/manualTimeController');
const authController = require('../controllers/authController');
const router = express.Router();

/**
 * @swagger
 * /api/v1/manualTime/addManualTimeRequest:
 *  post:
 *      tags:
 *          - Manual Time
 *      summary: "Add Manual Time"   
 *      security: [{
 *         bearerAuth: []
 *     }]        
 *      requestBody:
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          user:
 *                              type: string
 *                          date:
 *                              type: string
 *                              format: date
 *                          company:
 *                              type: string
 *                          project:
 *                              type: string 
 *                          manager:
 *                              type: string
 *                          slots:
 *                              type: string
 *      produces:
 *          - application/json
 *      responses:
 *          200:
 *              description: "Success"
 *              content:
 *                  application/json:
 *                      schema:
 *                          type: object
 *
 */
router.post('/addManualTimeRequest', authController.protect, manualTimeController.addManualTimeRequest);

/**
 * @swagger
 * /api/v1/manualTime/updateManualTimeRequest:
 *  post:
 *      tags:
 *          - Manual Time
 *      summary: "Update Manual Time"   
 *      security: [{
 *         bearerAuth: []
 *     }]        
 *      requestBody:
 *          content:
 *              application/json:
 *                  schema:
 *                      type: object
 *                      properties:
 *                          requestId:
 *                              type: string 
 *                          user:
 *                              type: string  
 *                          project:
 *                              type: string 
 *                          manager:
 *                              type: string
 *                          slots:
 *                              type: string
 *      produces:
 *          - application/json
 *      responses:
 *          200:
 *              description: "Success"
 *              content:
 *                  application/json:
 *                      schema:
 *                          type: object
 *
 */
router.post('/updateManualTimeRequest', authController.protect, manualTimeController.updateManualTimeRequest);

module.exports = router;